package org.spring.JPA2.entity;

import lombok.*;
import org.spring.JPA2.dto.Board0112DTO;
import org.spring.JPA2.dto.MemberDTO;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@Table(name = "boardEx")
public class Board0112 {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "board_id", nullable = false)
    private Long id;

    @Column(nullable = false)
    private Long cnt;

    @Column(nullable = false)
    private String title;

    @Column(nullable = false)
    private String content;


    @Column(nullable = false)
    private String writer;

    @Column(nullable = false)
    private Date create_date;

    //Relations with other table
//    @ManyToOne
//    @JoinColumn(name = "username")
//    private Member member;

//    @CreatedDate
//    private LocalDateTime createDate2;
//
//    @LastModifiedDate
//    private LocalDateTime updateDate2;

    //    Entity -> DTO 변환
    public static Board0112DTO toDTO(Board0112 entity) {
        Board0112DTO dto = new Board0112DTO();
        dto.setId(entity.getId());
        dto.setCnt(entity.getCnt());
        dto.setTitle(entity.getTitle());
        dto.setContent(entity.getContent());
        dto.setWriter(entity.getWriter());
        dto.setCreate_date(entity.getCreate_date());

        return dto;
    }

//    DTO -> Entity 변환
//    Id가 필요한 경우
    public static Board0112 toEntity(Board0112DTO dto) {
        Board0112 entity = new Board0112();
        entity.setId(dto.getId());
        entity.setCnt(dto.getCnt());
        entity.setTitle(dto.getTitle());
        entity.setContent(dto.getContent());
        entity.setWriter(dto.getWriter());
        entity.setCreate_date(dto.getCreate_date());

        return entity;
    }

//    Id가 필요 없는 경우
    public static Board0112 toEntityNoId(Board0112DTO dto) {
        Board0112 entity = new Board0112();
//        entity.setId(dto.getId());
        entity.setCnt(dto.getCnt());
        entity.setTitle(dto.getTitle());
        entity.setContent(dto.getContent());
        entity.setWriter(dto.getWriter());
        entity.setCreate_date(dto.getCreate_date());

        return entity;
    }




}
