package org.spring.JPA2.service;

import lombok.RequiredArgsConstructor;
import org.spring.JPA2.dto.Board0112DTO;
import org.spring.JPA2.entity.Board0112;
import org.spring.JPA2.repository.BoardRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class BoardService {

    @Autowired
    private BoardRepo boardRepo;



//    -------------------------------------Methods----------------------------------

//    ------------------------Insert------------------------
//    change DTO object to Entity object
    public void insertBoard(Board0112DTO dto){
        Board0112 insertEntity=Board0112.toEntityNoId(dto);
        boardRepo.save(insertEntity);
    }

//    -------------------------Select------------------------
//
    public List<Board0112DTO> lists(){

        List<Board0112DTO> dtoList=new ArrayList<>();

        List<Board0112> entityList=boardRepo.findAll();
        for(Board0112 each:entityList){
            dtoList.add(Board0112.toDTO(each));
        }

        return dtoList;

    }
//    --------------------------SelectWhereId-----------------
//    Extract one record in table with the criteria of a certain id.
    public Board0112DTO boardDetail(Long id) {
        Optional<Board0112> detailEntity= boardRepo.findById(id);

        if(detailEntity.isPresent()){
            return Board0112.toDTO(detailEntity.get());
        } else {
            return null;
        }
    }

//    ---------------------------Modify------------------------------
//    Show the info before changing it
    public Board0112DTO modifyView(Long id) {
        Optional<Board0112> changedEntity=boardRepo.findById(id);
        if(changedEntity.isPresent()){
            return Board0112.toDTO(changedEntity.get());
        } else {
            return null;
        }

    }
//    do the modifying
    public void modifyDo(Board0112DTO dto){
        Board0112 board0112 = Board0112.toEntity(dto);
        boardRepo.save(board0112);
    }

//    -----------------------------------Delete-----------------------
    public void delete(Long id) {
        boardRepo.deleteById(id);
    }
}
