package org.spring.JPA2.dto;

import lombok.*;
import org.spring.JPA2.entity.Board0112;
import org.springframework.beans.factory.annotation.Autowired;


import java.util.Date;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class Board0112DTO {


    private Long id;
    private Long cnt=0L;
    private String title;
    private String content;
    private String writer;
    private Date create_date=new Date();

//    @CreatedDate
//    private LocalDateTime createDate2;
//
//    @LastModifiedDate
//    private LocalDateTime updateDate2;





}
