package org.spring.JPA2.controller;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import lombok.RequiredArgsConstructor;
import org.spring.JPA2.dto.Board0112DTO;
import org.spring.JPA2.entity.Board0112;
import org.spring.JPA2.service.BoardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

@Controller
//@RequestMapping("/action")
@RequiredArgsConstructor
public class MainController {

//    ---------------------------------Constructor-------------------------------------------
//    First way
//    @Autowired
//    private BoardService boardService;

//    Second way

    @Autowired
    private BoardService boardService;
    private MainController(BoardService boardService){
        this.boardService=new BoardService();
    }


//    -------------------------------------Methods------------------------------------------
//    ----------------------------Insert---------------------------
//    InsertPage
    @GetMapping("/writeBoard")
    public String viewBoard(){
        return "board/writeBoard";
    }

//    InsertDo
    @PostMapping("/writeDo")
    public String writeBoardDo(@ModelAttribute Board0112DTO dto){
       boardService.insertBoard(dto);
        return "redirect:/boardList";
    }
//    ----------------------------------Select-------------------------
//    SelectEverythingPage
    @GetMapping("/boardList")
    public String showBoardList(Model model){
        List<Board0112DTO> lists= boardService.lists();
        model.addAttribute("boardList", lists);
        return "board/boardList";
    }

//    SelectWhereId
    @GetMapping("/detail/{id}")
     public String detail(@PathVariable Long id, Model model){

        Board0112DTO board = boardService.boardDetail(id);
        model.addAttribute("each_board", board);

        if(board != null){
            model.addAttribute("oneDetail", board);
            System.out.println("Your writing exists.");
        } else {
            System.out.println("Your writing doesn't exist.");
        }

            return "board/boardDetail";
    }
//    ------------------------Update----------------------------------
    //    UpdateWhereIdPage
    @GetMapping("/modifyView/{id}")
    public String modifyInfo(@PathVariable Long id, Model model){
        Board0112DTO boardView=boardService.modifyView(id);
        model.addAttribute("oneDetail", boardView);
        return "board/boardView";
    }
//    UpdateWhereIdDo
    @PostMapping("/modifyDo")
    public String modifyDo(@ModelAttribute Board0112DTO dto){
        boardService.modifyDo(dto);
        return "redirect:/boardList";
    }

//    @PostMapping("/post.do")
//    public String postBoardDo(@ModelAttribute("dto") Board0112DTO dto, Model model){
//        model.addAttribute("member", dto);
//        return "board/postBoard";
//    }

//    -------------------------Delete----------------------------------
    @GetMapping("/delete/{id}")
    public String delete(@PathVariable Long id){
        boardService.delete(id);
        return "redirect:/boardList";
    }
//    --------------------------------------Methods--------------------------------------


}
