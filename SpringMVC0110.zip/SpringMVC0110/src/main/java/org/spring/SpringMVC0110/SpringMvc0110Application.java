package org.spring.SpringMVC0110;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvc0110Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvc0110Application.class, args);
	}

}
