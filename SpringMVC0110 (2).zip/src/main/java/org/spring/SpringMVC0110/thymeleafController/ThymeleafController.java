package org.spring.SpringMVC0110.thymeleafController;

public class ThymeleafController {
}
