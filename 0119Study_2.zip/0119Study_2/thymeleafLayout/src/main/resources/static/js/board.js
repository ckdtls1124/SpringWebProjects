$('#writeDo').on('click', commentSuccess)

function commentSuccess(){
       const data={
            'comments':$('#comments').val(),
            'reply_writer':$('#reply_writer').val()
        }
        $.ajax({
            type: 'post',
            url: '/reply/write',
            data: data,
            success: function(res){

            const rs1=res;

            console.log('Resp of write: '+rs1);

            alert('덧글 작성이 완료되었습니다.')
            }

     });}


$('#showComments').on('click', showAllComments)

function showAllComments(){
    const data={
        'boardDto':$('#boardDto').val()
    }
    $.ajax({
        type: 'post',
        url: '/reply/showComments',
        data: data,
        success: function(res){
            let tag='';
            const rs=res;

            console.log('Replies with criteria of Board_id:'+rs);

            rs.forEach(function(el){
                tag=tag+"<tr>";
                    tag=tag+"<td>"+el.comments+"</td>";
                    tag=tag+"<td>"+el.reply_writer+"</td>";
                tag=tag+"</tr>"
            })
            $('#commentsSec tbody').html(tag);
           }

    })
}