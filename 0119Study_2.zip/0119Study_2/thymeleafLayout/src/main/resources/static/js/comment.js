$('#writeDo').on('click', successMs)

function successMs(){
    alert('댓글 작성을 완료했습니다.')
}