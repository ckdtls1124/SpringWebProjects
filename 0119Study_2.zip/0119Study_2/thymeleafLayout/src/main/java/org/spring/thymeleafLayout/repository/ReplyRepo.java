package org.spring.thymeleafLayout.repository;

import org.spring.thymeleafLayout.entity.BoardEntity;
import org.spring.thymeleafLayout.entity.ReplyEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import javax.persistence.Id;
import java.util.List;

public interface ReplyRepo extends JpaRepository<ReplyEntity, Long> {

    List<ReplyEntity> findAllByBoardEntityOrderById(Long boardEntity);

}
