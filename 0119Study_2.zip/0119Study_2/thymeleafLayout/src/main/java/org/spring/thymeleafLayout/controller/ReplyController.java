package org.spring.thymeleafLayout.controller;

import lombok.RequiredArgsConstructor;
import org.spring.thymeleafLayout.dto.BoardDto;
import org.spring.thymeleafLayout.dto.ReplyDto;
import org.spring.thymeleafLayout.entity.BoardEntity;
import org.spring.thymeleafLayout.service.ReplyService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/reply")
@RequiredArgsConstructor
public class ReplyController {

    private final ReplyService replyService;


//    Insert
    @PostMapping("/write")
    public @ResponseBody void commentWrite(@ModelAttribute ReplyDto dto){

        int rs=replyService.writeComment(dto);
        if(rs != 0){
            System.out.println("Writing a comment went successful");
        }
    }

    @PostMapping("/showComments")
    public @ResponseBody List<ReplyDto> showComments(@ModelAttribute BoardDto dto){
        List<ReplyDto> dtos=replyService.showComments(dto);
        return dtos;
    }



}
