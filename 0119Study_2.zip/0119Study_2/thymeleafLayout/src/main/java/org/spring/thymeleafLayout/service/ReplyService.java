package org.spring.thymeleafLayout.service;

import lombok.RequiredArgsConstructor;
import org.spring.thymeleafLayout.dto.BoardDto;
import org.spring.thymeleafLayout.dto.ReplyDto;
import org.spring.thymeleafLayout.entity.BoardEntity;
import org.spring.thymeleafLayout.entity.ReplyEntity;
import org.spring.thymeleafLayout.repository.BoardRepo;
import org.spring.thymeleafLayout.repository.ReplyRepo;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ReplyService {
    private final ReplyRepo replyRepo;
    private final BoardRepo boardRepo;

    //    Insert
    public int writeComment(ReplyDto dto) {
        ReplyEntity entity=ReplyDto.ReplyDtoReq.toEntity(dto);
        ReplyEntity a=replyRepo.save(entity);
        if(a != null){
            return 1;
        } else {
            return 0;
        }

    }

    public List<ReplyDto> showComments(BoardDto dto) {
        BoardEntity bEntity=BoardDto.BoardDtoReq.toEntity(dto);
        List<ReplyEntity> entities=replyRepo.findAllByBoardEntityOrderById(bEntity.getBoard_id());
        List<ReplyDto> dto1=new ArrayList<>();
        for(ReplyEntity i:entities){
            dto1.add(ReplyDto.ReplyDtoResp.toDto(i));
        }

        return dto1;
    }

    public BoardEntity searchBoard(Long boardId) {
       Optional<BoardEntity> rs=boardRepo.findById(boardId);
       if(rs.isPresent()){
           Long id=rs.get().getBoard_id();

       }
       return rs.get();
    }
}
