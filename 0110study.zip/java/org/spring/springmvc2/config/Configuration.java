package org.spring.springmvc2.config;

public class Configuration {
}
