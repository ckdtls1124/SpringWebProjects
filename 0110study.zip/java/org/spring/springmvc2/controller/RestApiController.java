package org.spring.springmvc2.controller;

import org.spring.springmvc2.dto.MemberDto;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController //페이지로 이동 안하고 데이터만 반환
@RequestMapping("/api")
public class RestApiController {

    @GetMapping("/get1")
    public String get1(){

        return "get1";
    }

    @GetMapping("/path1/{userId}")
    public String paht1(@PathVariable String userId){
        return userId;
    }

    @GetMapping("/path2/{userId}")
    public String paht2(@PathVariable ("userId") String uId){
        return uId;
    }

    @GetMapping("/param1") //form data
    public String param1(@RequestParam String userName,
                         @RequestParam String userAge){
        String data="이름 : " + userName + ", 나이: "+userAge;

        return data;
    }

    @GetMapping("/param2") //form data @ModelAttribute 생략가능
    public String param2(@ModelAttribute MemberDto dto){

                return dto.toString();
    }

    @PostMapping("/post1")
    public String post1(){
        return "post1";
    }

    @PostMapping("/post2")
    @ResponseBody
    public String post2(MemberDto dto){

        return dto.toString();
    }

    @PutMapping("/put1")
    public String put1(){
        return "put1";

    }

    @DeleteMapping(value = "/delete/{userId}")
    public String delete(@PathVariable String userId){

        return userId;
    }

}
