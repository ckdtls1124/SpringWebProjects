package org.spring.springmvc2.controller;

import org.spring.springmvc2.dto.MemberDto;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.time.LocalDateTime;
import java.util.*;

@Controller
@RequestMapping("/basic")
public class BasicController {

    @GetMapping("/main")
    public String Rmain(){
        return "basic/main";
    }

    // 요청 URL "/basic/basicMain
    @GetMapping("/basicMain")
    public String main(){

        // template/basic/basicMain.html
        return "basic/basicMain";
    }

    @GetMapping("/project1")
    public String project1(Model model){
        model.addAttribute("name","basicProject");
        return "basic/project1";
    }


    @GetMapping("/project2")
    public String project2(@ModelAttribute MemberDto dto, Model model){
        model.addAttribute("member",dto);
        return "basic/project2";
    }

    @GetMapping("/project3")
    public ModelAndView project3(){
        ModelAndView mv= new ModelAndView();

        Map<String,Object> info = new HashMap<>(); //키: 값
        info.put("userName","son");
        info.put("userAge",30);
        info.put("data", LocalDateTime.now());

//        Set<String> keys = info.keySet();
//        Iterator<String> iterator = keys.iterator();
//
//            while (iterator.hasNext()) {
//            String key = iterator.next();
//        }


        List<String> project = new ArrayList<>(); //리스트 foreach
        project.add("spring");
        project.add("jsp");
        project.add("thymeleaf");
        project.add("jpa");



        mv.addObject("info",info); //View 전달 객체
        mv.addObject("project",project); //View 전달 객체
        mv.setViewName("basic/project3"); //view

        return mv;
    }


    @GetMapping("/insertOk")
    public String insertOk1(Model model, MemberDto dto){

        model.addAttribute("dto",dto);
        //페이지 이동
        return "basic/insert";
    }

    @PostMapping("/insertOk")
    public String insertOk2(@ModelAttribute("dto") MemberDto dto, Model model){
        model.addAttribute("member",dto);
        return "main";


    }


}
