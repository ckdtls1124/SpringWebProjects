package org.spring.springmvc2.repository;

public interface Repository {
}
