package org.spring.springmvc2.service;

public class Service {
}
