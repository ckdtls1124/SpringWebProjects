package org.spring.springmvc2.entity;

public class Entity {
}
