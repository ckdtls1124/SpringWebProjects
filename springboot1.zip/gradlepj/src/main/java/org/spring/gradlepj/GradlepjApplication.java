package org.spring.gradlepj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GradlepjApplication {

	public static void main(String[] args) {
		SpringApplication.run(GradlepjApplication.class, args);
	}

}
