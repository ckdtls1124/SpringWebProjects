package org.spring.mavenpj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MavenpjApplication {

	public static void main(String[] args) {
		SpringApplication.run(MavenpjApplication.class, args);
	}

}
