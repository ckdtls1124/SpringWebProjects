use springdb0111;
show tables;


desc board0111;

insert into board0111(cnt, content, create_date, title, writer) values (1, 'c1', now(), 'title1', 'text1');
insert into board0111(cnt, content, create_date, title, writer) values (2, 'c2', now(), 'title2', 'text2');
insert into board0111(cnt, content, create_date, title, writer) values (3, 'c3', now(), 'title3', 'text3');

select * from board0111;