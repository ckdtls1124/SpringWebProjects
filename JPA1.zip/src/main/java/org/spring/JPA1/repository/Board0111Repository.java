package org.spring.JPA1.repository;

import org.spring.JPA1.entity.Board0111Entity;
import org.spring.JPA1.service.Board0111Service;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface Board0111Repository extends JpaRepository<Board0111Entity, Long> {

//    void insertBoard(Board0111Entity board);
//    void getBoard(Board0111Entity board);


}
