package org.spring.JPA1.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.time.LocalDateTime;
import java.util.*;

@Controller
@RequestMapping("/basic")
public class JPABasicController {
    @GetMapping("/main")
    public String main1() {return "basic/main";}
    @GetMapping("/basicMain")
    public String main2() {return "basic/basicMain";}
    @GetMapping("/project1")
    public String project1() {return "basic/project1";}
    @GetMapping("/project2")
    public String project2() {return "basic/project2";}
//    @GetMapping("/project3")
//    public String project3() {
//        ModelAndView mv=new ModelAndView();
//
//        Map<String, Object> info=new HashMap<>();
//        info.put("username", "son");
//        info.put("userage", 30);
//        info.put("data", LocalDateTime.now());
//
//        List<String> project=new ArrayList<>();
//        project.add("Spring");
//        project.add("JSP");
//        project.add("Thymeleaf");
//        project.add("JPA");
//
//        mv.addObject("info", info);
//        mv.addObject("project", project);
//        mv.setViewName("basic/project3");
//
//        return mv;
//    }
//    @GetMapping("/main")
//    public String main1() {return "basic/main";}
//    @GetMapping("/main")
//    public String main1() {return "basic/main";}
//




}
