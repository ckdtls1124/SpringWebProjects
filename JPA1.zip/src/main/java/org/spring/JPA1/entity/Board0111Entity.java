package org.spring.JPA1.entity;

import lombok.*;

import javax.persistence.*;
import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Setter
@Getter
@Entity //basic constructor, constructor with every attribute is needed
@Table(name="board0111", uniqueConstraints = {@UniqueConstraint(
    name="writerCon", columnNames = {"writer"}
        )})
public class Board0111Entity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) //auto-increment
    private Long id; // setting primary key

    @Column(name="title", unique = true, nullable = false)
    private String title;
    private String writer;
    private String content;
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;
    private Long cnt=0L;  // standard 0







}
