package org.spring.JPA1.service;

import lombok.RequiredArgsConstructor;
import org.spring.JPA1.entity.Board0111Entity;
import org.spring.JPA1.repository.Board0111Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class Board0111Service {

//    @Autowired
//    private Board0111Repository Board0111Repository;

    @Autowired
    private Board0111Repository board0111Repository;
    public Board0111Service(Board0111Repository board0111Repository){
        this.board0111Repository=board0111Repository;
    }

    public void insertBoard(Board0111Entity board){
        board0111Repository.save(board);
    }

    public Board0111Entity getBoard(Board0111Entity board) {
        return board0111Repository.findById(board.getId()).get();
    }


//    public List<Board0111Entity> boardList(){
//
//        List<Board0111Entity> Lists=(List<Board0111Entity>) Board0111Repository.findAll();
//        return Lists;
//    }
}
