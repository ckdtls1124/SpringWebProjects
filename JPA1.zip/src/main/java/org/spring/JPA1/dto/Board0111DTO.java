package org.spring.JPA1.dto;

import lombok.*;

import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Setter
@Getter
public class Board0111DTO {
    private Long id; // setting primary key
    private String title;
    private String writer;
    private String content;
    private Date createDate;
    private Long cnt=0L;  // standard 0
}
