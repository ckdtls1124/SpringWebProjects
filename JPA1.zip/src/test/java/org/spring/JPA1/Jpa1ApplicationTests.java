package org.spring.JPA1;

import org.junit.jupiter.api.Test;
import org.spring.JPA1.entity.Board0111Entity;
import org.spring.JPA1.repository.Board0111Repository;
import org.spring.JPA1.service.Board0111Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Date;

@SpringBootTest
class Jpa1ApplicationTests {

	@Autowired
	private Board0111Service board0111Service;

	@Test
	void contextLoads() {
		Board0111Entity board=new Board0111Entity();
		board.setCnt(10L);
		board.setTitle("title7");
		board.setContent("Content7");
		board.setWriter("writer7");
		board.setCreateDate(new Date());


		board0111Service.insertBoard(board);
		board0111Service.getBoard(board);
	}

}
